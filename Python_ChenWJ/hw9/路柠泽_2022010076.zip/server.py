import http.server
import socketserver
import sys
import random
from urllib.parse import urlparse, parse_qs


ans = random.randint(1, 1000)

class GuessNumberHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        input = urlparse(self.path)
        if input.path != "/guess":
            self.send_error(404, "Not Found")
            return
        Q = parse_qs(input.query)
        if "num" not in Q:
            self.send_error(400, "Bad Request")
            return
        try:
            num = int(Q["num"][0])
        except ValueError:
            self.send_error(400, "Bad Request")
            return
        if num < 1 or num > 1000:
            R = "Invalid input"
        elif num < ans:
            R = "Too low"
        elif num > ans:
            R = "Too high"
        else:
            R = "Correct! The number was " + str(ans)
        self.send_response(200)
        self.send_header("Content-type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(R.encode("utf-8"))

    # 屏蔽默认日志
    def log_message(self, format, *args):
        return

if __name__ == "__main__":
    PORT = 8000
    with socketserver.TCPServer(("127.0.0.1", PORT), GuessNumberHandler) as httpd:
        print(f"服务端启动成功！")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n服务端已关闭。")
            sys.exit(0)