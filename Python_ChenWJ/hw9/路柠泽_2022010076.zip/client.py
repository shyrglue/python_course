import requests

server = "http://127.0.0.1:8000/guess?num="

def main():
    while True:
        try:
            num = int(input("请输入1~1000的整数: "))
        except ValueError:
            print("请输入合法的整数！")
            continue
        if num < 1 or num > 1000:
            print("请输入1~1000范围内的整数！")
            continue

        try:    #处理服务端未启动
            R = requests.get(server + str(num), timeout=3)
        except Exception:
            print("无法连接服务端，请确认服务端已启动。")
            break
        if R.status_code != 200:    #解析响应码
            print("错误代码：" + str(R.status_code))
            break
        M = R.text    #解析响应信息
        print(M)
        if M.startswith("C"):
            break

if __name__ == "__main__":
    main()